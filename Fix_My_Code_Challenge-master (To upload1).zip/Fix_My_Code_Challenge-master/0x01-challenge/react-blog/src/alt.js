var Alt = require('alt');
var alt = new Alt();
module.exports = alt;