const inputSizeInstance = (
  <form>
    <Input type="text" bsSize="large" placeholder="Large text" />
    <Input type="text" bsSize="medium" placeholder="Normal text" />
    <Input type="text" bsSize="small" placeholder="Small text" />
  </form>
);

React.render(inputSizeInstance, mountNode);
